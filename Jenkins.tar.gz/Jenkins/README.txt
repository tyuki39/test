##----------------------------------------
## 概要

Jenkinsを使って、次のことを行うためのセットです。
(1) checkstyleによる静的コードチェック
(2) pmdによる静的コードチェック
(3) cpdによるクローンコードチェック

  (1)と(2)&(3)は独立に使えます。
  (2)&(3)は同時にインストールされますが、片方のみを使用しても構いません。

Macでも予定通りに動けば、短時間で(1),(2),(3)の環境を構築できます。
静的コードチェックはルールを絞らないとうるさいかも知れませんが、
モチベーション向上に使えるのではないかと思います。


##----------------------------------------
## ディレクトリ構成

ディレクトリ構成は以下の通りです。
+
|   README.txt            : 本書です。
|   Jenkins1.png          : Jenkinsの[ビルド]の設定例です。
|   Jenkins2.png          : Jenkinsの[ビルド後の処理]の設定例です。
|   common.properties     : checkstyle/do_checkstyle.xml と
|                           pmd/do_pmdcpd.xml が共通に読み込むプロパティです。
|   checkstyle.properties : checkstyle/install_tool.gant が 自動生成するファイルの例です。
|   pmd.properties        : pmd/install_tool.gant が 自動生成するファイルの例です。
|   install_plugin.gant   : プラグインのインストールを自動化するための Gant ファイルです。
|   
+---checkstyle
|       do_checkstyle.xml : checkstyleの呼び出しに特化したAntファイルです。
|       install_tool.gant : checkstyleのツールのダウンロード、解凍、
|                           checkstyle.propertiesの自動生成を担当する Gant ファイルです。
|       
+---pmd
        do_pmdcpd.xml     : pmdとcpdの呼び出しに特化したAntファイルです。
        install_tool.gant : pmdのツールのダウンロード、解凍、
                            pmd.propertiesの自動生成を担当する Gant ファイルです。


##----------------------------------------
## Jenkinsへの組み込み方
(1), (2), (3)共通
  1. Jenkinsを起動しておきます。
  2. install_plugin.gant 内の JENKINS_HOME と JENKINS_URL を変更してください。
  3. **/install_tool.gant 内の INSTALL_ROOT の "." を
     ツールをインストールしたいディレクトリパスに変更してください。
  4. Jenkins1.png と Jenkins2.png を参考にして、Jenkinsで結果が得られるようにします。
  5. 解析対象のソースは、common.properties 内の src.dir で決定するようにしています。


(1)を使う場合
  1. gant -DJPLUGIN_NAME=checkstyle -f install_plugin.gant
     を実行すると、Jenkinsにcheckstyleプラグインと依存プラグインがインストールされます。

  2. cd checkstyle

  3. gant -f install_tool.gant
     を実行すると、checkstyleのツールのダウンロード、解凍、
     checkstyle.propertiesの自動生成が行われます。


(2)を使う場合
  1. gant -DJPLUGIN_NAME=pmd -f install_plugin.gant
     を実行すると、Jenkinsにpmdプラグインと依存プラグインがインストールされます。
     ※ (3)だけを使う場合は不要です。

  2. cd pmd

  3. gant -f install_tool.gant
     を実行すると、pmdのツールのダウンロード、解凍、
     pmd.propertiesの自動生成が行われます。
     ※ (2)と(3)の両方を使う場合は、一度だけ実行すればOKです。


(3)を使う場合
  1. gant -DJPLUGIN_NAME=dry -f install_plugin.gant
     を実行すると、Jenkinsにpmdプラグインと依存プラグインがインストールされます。
     ※ (2)だけを使う場合は不要です。

  2. cd pmd

  3. gant -f install_tool.gant
     を実行すると、pmdのツールのダウンロード、解凍、
     pmd.propertiesの自動生成が行われます。
     ※ (2)と(3)の両方を使う場合は、一度だけ実行すればOKです。


##----------------------------------------
## 補足
(1), (2), (3)をすべて入れた場合、プロジェクトのサブメニューなどが乱雑になってきます。
煩わしい場合は、checkstyle、pmd、cpdのプラグインを入れる代わりに、

  gant -DJPLUGIN_NAME=violations -f install_plugin.gant

を実行して結果を一まとめにしてくれるプラグインを入れると良いです。
